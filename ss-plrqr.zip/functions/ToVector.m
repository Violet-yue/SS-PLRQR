function v = ToVector(img)
% takes MxNx3 picture and returns (MN)x3 vector
sz = size(img);
v = reshape(img, [prod(sz(1:2)) sz(3)]);
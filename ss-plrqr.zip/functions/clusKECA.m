%%
% Compute the entropic components of KECA method for classification
%
% [Phi1,Phi2] = clusKECA(test_data,train_data,ker,nec,r_rate)
% 
% inputs:
% 
% - test_data:      testing data matrix, each row is one observation, each column is one feature 
% - train_data:     training data matrix, each row is one observation, each column is one feature
% - sigma:          kernel width parameter
% outputs:
% 
% - Phi1:           dimensionanlity-reduced testing data; 
% - Phi2:           dimensionanlity-reduced training data;
%
% Copyright (c) 2019  Chengzu Bai

function Phi = clusKECA(Data,ker,nec,r_rate)


P = Cholkernel(Data,ker,r_rate*nec,r_rate);

    D = -5;
    kk = 0;
    
    while(min(diag(D))<0 || sum(abs(imag(diag(D))))>0)    
%         [V, D] = eigs(P'*P,size(P'*P,1));
        [V, D] = eig(P'*P);
        kk = kk + max([sum(abs(imag(diag(D)))) abs(min(diag(D)))]);
    end
    
    V = P*V;
    
    valores_keca = sum((V*(D.^0.5))).^2;
    
    [~, ind_keca] = sort(valores_keca,'descend');
    
    Phi=V(:,ind_keca);
    Phi=Phi(:,1:nec);

return

%% Computing kernel matrix
function [K] = kernelKECA(data,sigma)
    
    X = data';
    n1sq = sum(X.^2);
    n1 = size(X,2);
    D = (ones(n1,1)*n1sq)' + ones(n1,1)*n1sq -2*X'*X;
    
    K = (1/size(X,1))*(1/(sigma*sqrt(2*pi)))*exp(-D/(2*sigma^2));
% end
    
% function K=innerkernel(data1,data2,ker)
% switch ker.type
%     case 'gaussian'
%         K=Kgaussian(ker.sigma,data1,data2);
%     case 'ploy'
%         K=(data1*data2'+1).^ker.sigma;
%     case 'linear'
%         K=data1*data2';
% end
    
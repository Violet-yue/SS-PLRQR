%
% ESTIMATESIGMA4 Estimates differents sigma parameters (RBF kernel lengthscale) 
% from available data. Four criteria are used: 
%      * mean distance among all data points, 
%      * 15% of the mean distance, 
%      * Silverman rule
%      * Maximum Likelihood
%
% Input:  - X:     Training data. (Size: [dxM]).
% Output: - sigma: sigma parameter. (scalar).
%
% Copyright (c) 2013  Emma Izquierdo-Verdiguier, Valero Laparra, 
%                     Robert Jenssen, Luis Gómez-Chova, and Gustavo Camps-Valls
%
%                     emma.izquierdo@uv.es, http://isp.uv.es
%

function sigma=estimateSigma4(X)

ind = randperm(size(X,2));
dat1 = X(:,ind(1:round(size(X,2)*0.9)));
dat2 = X(:,ind(round(size(X,2)*0.9)+1:end));

SIGMAS = logspace(-2,2,25);       % estimation of sigma parameter
for ind_s =1:length(SIGMAS)
   
    n1sq = sum(dat1.^2);
    n1 = size(dat1,2);
    n2sq = sum(dat2.^2,1);
    n2 = size(dat2,2);
    D = (ones(n2,1)*n1sq)' + ones(n1,1)*n2sq -2*dat1'*dat2;
    
    K = (1/(SIGMAS(ind_s)*sqrt(2*pi)))*exp(-D/(2*SIGMAS(ind_s)^2));
    
    MLE(ind_s) = sum(log(sum(K)./size(K,2)));
    BAY(ind_s) = sum(log(sum(K)./size(K,2)))+log(1./SIGMAS(ind_s));
    en(ind_s)=sum(sum(K));
end

% Best ML
[mm ii] = max(MLE);

% Best Bayesian
[mm iii] = max(BAY);

%Best entropy
[mm iv] = max(en);

% for n=1:size(X,1)
%     [F,XI,aux(n)]=ksdensity(X(n,:));
% end

sigma{1} = SIGMAS(ii);
sigma{2} = SIGMAS(iii);
sigma{3} = median(pdist(X'));
sigma{4} = mean(pdist(X'));
% sigma{5} = mean(aux);

%% http://sfb649.wiwi.hu-berlin.de/fedc_homepage/xplore/ebooks/html/spm/spmhtmlnode18.html

% Silverman rule
n = size(X,2);
d = size(X,1);
sigma{6} = ((4/(d+2))^(1/(d+4))) * n^(-1/(d+4)).*std(X');

% KDE
% Sigma predition using KDE (leave-on-out maximum likelihood)
% px = ksdensity(X,'lcv');
% s = getBW(px);
% sigma{7} = unique(s);
 

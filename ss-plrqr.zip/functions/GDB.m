[no_lines, no_rows, no_bands] = size(img);
result = reshape(R(:,1),no_lines,no_rows);
map2=label2colord(result,'lk');
imshow(map2);
img1=reshape(img,no_lines*no_rows,no_bands);
rgbb=img1(:,[35 16 9]);
max(rgbb(:,1:3))
min(rgbb(:,1:3))
mean(rgbb(:,1:3))
rgb0=reshape(rgbb,no_lines,no_rows,3);
rgb=mat2gray(img);&rgb0
imshow(rgb)
imshow(rgb0)
figure

subplot(1,2,1);
func_hyperImshow(img,[101 99 120])
title('(a)');

subplot(1,2,2);
map2=label2colord(SVMresult,'lk');
imshow(map2);
title('(b)');

imshow(img)
subplot(1,2,1);
func_hyperImshow(img,[138,140 44])
title('(a)');

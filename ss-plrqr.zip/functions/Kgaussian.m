function [K] =Kgaussian(sigma,data1,data2,norm2tr)
    
  
        XXh1 = sum(data1.^2,2)*ones(1,size(data2,1));
        XXh2 = sum(data2.^2,2)*ones(1,size(data1,1));
        omega = XXh1+XXh2' - 2*data1*data2';
        K = exp(-omega./sigma);
   
    
function [labels] = superp(img1,hb)
 
    grey_img=img1;
    labels = mex_ers(double(grey_img),hb); 
    [bmap] = seg2bmap(labels,size(img1,2),size(img1,1));
    bmapOnImg =img1;
    idx = find(bmap>0);
    timg =  grey_img;
    timg(idx) = 255;
    bmapOnImg(:,:,2) =timg ;
    bmapOnImg(:,:,1) = grey_img;
    bmapOnImg(:,:,3) = timg;
    figure;
    fig_1=imshow(bmapOnImg,[]);
    labels=labels+1;

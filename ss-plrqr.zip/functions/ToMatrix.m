function m = ToMatrix(v,s)
% reshape (MN)xP vector to a matrix with dimension MxNxP
m = reshape(v,s);
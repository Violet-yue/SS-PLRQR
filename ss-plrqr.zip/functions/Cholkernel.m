function [P,BS,error]=Cholkernel(train,ker,subsetsize,errorbound)
%% Pivoted Cholesky decomposingthe kernel matrix, 
%where the basic set is chosen by pivoting the maximum diag of Schur complement. 
%%
%Input:
%  train----------training samples matrix, (one row one sample) 
%  ker.type-------kernel function name string, like 'linear', 'poly', 'gaussian' etc.  
%  ker.sig--------kernel parameters corresponding to ker.type.
%  subsetsize-----random subset size.
%  errorbound-----approximation error bound on trace norm
%Output:

%% 
%
m=size(train,1);   r=1;
BS=zeros(0,subsetsize);
N= 1:m;
norm2tr = sum(train.*train,2);       %for save time for gaussian kernel
d_K=innerdiagker(norm2tr,ker);       %The diag the kernel matrix    
error(r) = sum(d_K);
P=zeros(m,subsetsize);
while error(r)>errorbound && r<=subsetsize
    %find the maximum diag of Shur compliment:
    [~,index]=max(d_K(N));s_in=N(index);N(index)=[];
    k_in   =innerkernel(train,train(s_in,:),ker,norm2tr);
    if r==1
        p=k_in/k_in(s_in);
    else
        u=P(s_in,:)';nu=sqrt(k_in(s_in)-u'*u);
        p=(k_in-P*u)/nu;        p(BS)=0;
    end
    P(:,r)=p; BS(r)=s_in;
    d_K(N)=d_K(N)-p(N).^2; 
    error(r+1) = sum(d_K(N));
    r=r+1;
end
error=error(end);
return

function K=innerkernel(data1,data2,ker,norm2tr)
switch ker.type
    case 'gaussian'
        K=Kgaussian(ker.sigma,data1,data2,norm2tr);
    case 'ploy'
        K=(data1*data2'+1).^ker.sigma;
    case 'linear'
        K=data1*data2';
end

function dg=innerdiagker(norm2tr,ker)
switch ker.type
    case 'gaussian'
        dg=ones(length(norm2tr),1);
    case 'ploy'
        dg=(norm2tr+1).^ker.sigma;
    case 'linear'
        dg=norm2tr;
end
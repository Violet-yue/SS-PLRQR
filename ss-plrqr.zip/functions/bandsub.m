function img2=bandsub(img,K)

[M,N,Band] = size(img);
sz = size(img);
img_src = double(img);
img_src = reshape(img_src,sz(1)*sz(2),sz(3));
img_src = img_src';

%% normalization

imgz = img_src(:);
imgz = mapminmax(imgz',0,1);
imgs = reshape(imgz,Band,M*N);

S = get_D(imgs');

   
bandSubspace = subspacePart(S,Band,K+1);
    
%% compute information entropy   
 totalNumber = M*N;  
randNumber = floor(totalNumber*0.01);  % hyperparameter  0.01 or 0.1
for i=1:Band
    randIndex(i,:) = randperm(totalNumber,randNumber);
    imgx(i,:) = imgs(i,randIndex(i,:));
end

for i = 1:Band
    mVar(i) = Entrop(imgx(i,:));%
end

mVar = (mVar - min(mVar)) / (max(mVar) - min(mVar));
mVar = mVar';

V1=zeros(M*N,K);
for i = 1:K
    V=img_src((bandSubspace(i):bandSubspace(i+1)-1),:)'*mVar(bandSubspace(i):bandSubspace(i+1)-1);
    V=V';
    V1(:,i)=V/sum(bandSubspace(i):bandSubspace(i+1)-1);
end
 img2=reshape(V1,M,N,K);
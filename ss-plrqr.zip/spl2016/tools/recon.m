function X = recon(D,P)

X = D.*cos(P) + i*D.*sin(P);
